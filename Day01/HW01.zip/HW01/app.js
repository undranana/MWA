var fibonacci = require("./fib");

console.log("Fibonacci number of 10 (hard coded): ",fibonacci.fib_hard_coded(10));

console.log("Fibonacci number of -15 (calculated): ",fibonacci.calc_fib(-15));